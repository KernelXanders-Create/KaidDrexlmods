import sys, json, numpy as np, os
from scipy import ndimage as nd
D=sys.argv[1]; os.environ['PACK_C']=sys.argv[2]; sys.path.insert(0,sys.argv[3])
h=np.load(D+"/suddra_height_cm.npz",allow_pickle=False)["height_cm"]/100
m=np.load(D+"/suddra_masks.npz",allow_pickle=False)
for name,mask in [("ai_dry",m["ai_dry"]==1),("h>=0.5 & not water",(h>=0.5)&(m["water"]==0)),("h>0.3",h>0.3)]:
    lab,n=nd.label(mask,structure=np.ones((3,3)))
    sizes=np.bincount(lab.ravel())
    print("==",name,"components",n,"largest km2",round(sizes[1:].max()*16/1e6,1))
    import op3r,op4r
    for o in (op3r,op4r):
        out={}
        for t in o.SITES:
            x,y=t[6]; l=lab[int(y/4),int(x/4)]
            if l==0:   # nearest labelled cell within 100 m
                i,j=int(y/4),int(x/4); w=lab[i-25:i+26,j-25:j+26]; nz=w[w>0]; l=-np.bincount(nz).argmax() if nz.size else 0
            out.setdefault(int(abs(l)),[]).append(t[0]+("*" if l<0 else ""))
        big=sorted(out.items(),key=lambda kv:-sizes[kv[0]] if kv[0] else 0)
        for l,ids in big: print("  comp",l,"%.1f km2"%(sizes[l]*16/1e6) if l else "none",ids)
    for nm,xy in [("1-F FOB",(8200,3600))]:
        print("  ",nm,lab[int(xy[1]/4),int(xy[0]/4)])
