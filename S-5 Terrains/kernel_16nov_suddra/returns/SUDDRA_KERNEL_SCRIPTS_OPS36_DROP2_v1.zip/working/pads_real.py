import sys, json, math, numpy as np
D=sys.argv[1]; plans=sys.argv[2:]
h=np.load(D+"/suddra_height_cm.npz",allow_pickle=False)["height_cm"].astype(np.float32)/100
m=np.load(D+"/suddra_masks.npz",allow_pickle=False)
W=m["water"]; A=m["ai_dry"]
def foot(x,y,hx,hy,yaw):
    t=math.radians(yaw); xs=np.arange(-hx,hx+0.1,4); ys=np.arange(-hy,hy+0.1,4)
    U,V=np.meshgrid(xs,ys); X=x+U*math.cos(t)+V*math.sin(t); Y=y-U*math.sin(t)+V*math.cos(t)
    j=np.clip(np.rint(X/4).astype(int),0,4095); i=np.clip(np.rint(Y/4).astype(int),0,4095); return i,j
rows=[]
for p in plans:
    P=json.load(open(p))
    for s in P["sites"]:
        for mb in s["members"]:
            pad=mb.get("pad") if isinstance(mb.get("pad"),dict) else {}
            hx,hy=pad.get("hx",10),pad.get("hy",10); zp=pad.get("z")
            i,j=foot(mb["x"],mb["y"],hx,hy,mb.get("yaw",0) or 0)
            g=h[i,j]; w=W[i,j].mean(); a=A[i,j].mean()
            ci,cj=int(round(mb["y"]/4)),int(round(mb["x"]/4))
            cut=float(g.max()-zp) if zp is not None else None; fill=float(zp-g.min()) if zp is not None else None
            rows.append(dict(op=P["op"],site=s["id"],grade=s.get("grade"),comp=mb["comp"],x=mb["x"],y=mb["y"],hx=hx,hy=hy,zpad=zp,
              zc=round(float(h[ci,cj]),2),gmin=round(float(g.min()),2),gmax=round(float(g.max()),2),
              cut=None if cut is None else round(cut,2),fill=None if fill is None else round(fill,2),water=round(100*w,1),aidry=round(100*a,1)))
json.dump(rows,open(sys.argv[0].replace(".py","_out.json"),"w"),indent=1)
for r in rows: print(r["op"],r["site"],r["comp"][:38].ljust(38),"zc %+.2f range %+.2f..%+.2f pad %s water %5.1f%% aidry %5.1f%%"%(r["zc"],r["gmin"],r["gmax"],r["zpad"],r["water"],r["aidry"]))
