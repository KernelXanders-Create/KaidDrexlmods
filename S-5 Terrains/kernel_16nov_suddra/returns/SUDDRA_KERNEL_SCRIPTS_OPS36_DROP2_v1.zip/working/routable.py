import sys, os, numpy as np
from scipy import ndimage as nd
os.environ['PACK_C']=sys.argv[1]; sys.path.insert(0,sys.argv[2])
import op3r, op4r
H=np.load(sys.argv[1]+"/ground/height_whole_cm.npz")["height_cm"]/100.0
water=H<=0.3
Hf=nd.gaussian_filter(H,1.0); gy,gx=np.gradient(Hf,5.0); sl=np.hypot(gx,gy)
tests={"dry only (H>0.3)":~water,
 "band 10 m off water":~nd.binary_dilation(water,iterations=2),
 "+ side slope <=0.5":~nd.binary_dilation(water,iterations=2)&(sl<=0.5),
 "+ no cliff (slope>0.9 +10 m)":~nd.binary_dilation(water,iterations=2)&(sl<=0.5)&~nd.binary_dilation(sl>0.9,iterations=2)}
for k,v in tests.items():
    lab,n=nd.label(v,structure=np.ones((3,3)))
    for o in (op3r,op4r):
        ls={}
        for t in o.SITES:
            x,y=t[6]; i,j=int(y/5),int(x/5); w=lab[i-12:i+13,j-12:j+13]; nz=w[w>0]
            ls.setdefault(int(np.bincount(nz).argmax()) if nz.size else 0,[]).append(t[0])
        sz=np.bincount(lab.ravel())
        print(k,"op",o.__name__,"groups:",len(ls),"|", "; ".join(f"{sz[l]*25/1e6:.1f}km2:{len(v)}" + (":"+",".join(v) if len(v)<6 else "") for l,v in sorted(ls.items(),key=lambda kv:-len(kv[1]))))
print("share of dry cells with slope>0.5:", round(float(((sl>0.5)&~water).sum()/(~water).sum()),3))
