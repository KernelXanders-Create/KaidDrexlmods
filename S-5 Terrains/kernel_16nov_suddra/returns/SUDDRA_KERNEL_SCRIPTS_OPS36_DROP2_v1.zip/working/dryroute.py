"""shortest dry path (router's water rule: H > 0.3 m, 10 m clear) between site pairs on the full map; Dijkstra on 5 m grid via scipy csgraph"""
import sys, numpy as np, math
from scipy import ndimage as nd
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
H=np.load(sys.argv[1]+"/ground/height_whole_cm.npz")["height_cm"]/100.0
s=2  # 10 m lattice to keep it small
h=H[::s,::s]; free=~nd.binary_dilation(H<=0.3,iterations=2)[::s,::s]
ny,nx=h.shape; idx=np.arange(ny*nx).reshape(ny,nx); R=[];C=[];W=[]
for dj,di in [(0,1),(1,0),(1,1),(1,-1)]:
    A=np.s_[0:ny-dj, max(0,-di):nx-max(0,di)]; B=np.s_[dj:ny, max(0,di):nx-max(0,-di)]
    ok=free[A]&free[B]; R.append(idx[A][ok]); C.append(idx[B][ok]); W.append(np.full(ok.sum(),10*math.hypot(dj,di)))
G=coo_matrix((np.concatenate(W),(np.concatenate(R),np.concatenate(C))),shape=(ny*nx,ny*nx)).tocsr()
pairs=[((8200,3600),(11600,3400),"1-F to 3-M2"),((8300,3780),(13600,5400),"1-F to 3-M1"),((11600,3400),(13200,2600),"3-M2 to 3-F"),((9600,6000),(10390,7105),"4-04 to 4-F"),((9200,8600),(5190,7790),"4-M3 to 4-M1"),((9200,8600),(12564,8155),"4-M3 to 4-10")]
def node(x,y):
    i,j=int(y/10),int(x/10); w=np.argwhere(free[i-5:i+6,j-5:j+6]); 
    if not len(w): return None
    k=w[np.argmin(((w-5)**2).sum(1))]; return idx[i-5+k[0],j-5+k[1]]
for a,b,nm in pairs:
    na,nb=node(*a),node(*b)
    if na is None or nb is None: print(nm,"end not on free ground"); continue
    d,pred=dijkstra(G,indices=na,return_predecessors=True,directed=False,limit=60000)
    if not np.isfinite(d[nb]): print(nm,"NO DRY PATH within 60 km"); continue
    p=[nb]
    while p[-1]!=na: p.append(pred[p[-1]])
    P=np.array([(q%nx*10,q//nx*10) for q in p])
    print(nm,"dry path %.0f m (straight %.0f m), x %d..%d, y %d..%d"%(d[nb],math.dist(a,b),P[:,0].min(),P[:,0].max(),P[:,1].min(),P[:,1].max()))
