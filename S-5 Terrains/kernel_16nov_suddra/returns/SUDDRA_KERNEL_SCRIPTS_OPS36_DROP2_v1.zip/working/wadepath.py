import sys, numpy as np, math
from scipy import ndimage as nd
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
D=sys.argv[1]; s=2   # 8 m lattice
h=np.load(D+"/suddra_height_cm.npz",allow_pickle=False)["height_cm"][::s,::s]/100.0
m=np.load(D+"/suddra_masks.npz",allow_pickle=False); band=m["depth_band"][::s,::s]
dry=h>0.3; wade=(~dry)&(band<=1)    # band 0 low ground or band 1 wade
ny,nx=h.shape; idx=np.arange(ny*nx).reshape(ny,nx); c=4.0*s
pairs=[((8200,3600),(11600,3400),"1-F to 3-M2"),((8300,3780),(13600,5400),"1-F to 3-M1"),((11600,3400),(13200,2600),"3-M2 to 3-F"),((9600,6000),(10390,7105),"4-04 to 4-F"),((9600,6000),(8240,6970),"4-04 to 4-M2"),((9200,8600),(5190,7790),"4-M3 to 4-M1"),((9200,8600),(12564,8155),"4-M3 to 4-10")]
for mode,pen in [("dry only",None),("dry + wade crossings",1.0)]:
    R=[];C=[];W=[]
    for dj,di in [(0,1),(1,0),(1,1),(1,-1)]:
        A=np.s_[0:ny-dj, max(0,-di):nx-max(0,di)]; B=np.s_[dj:ny, max(0,di):nx-max(0,-di)]
        L=c*math.hypot(dj,di)
        if pen is None: ok=dry[A]&dry[B]; w=np.full(ok.sum(),L)
        else:
            okA=dry[A]|wade[A]; okB=dry[B]|wade[B]; ok=okA&okB
            w=np.where(dry[A][ok]&dry[B][ok],L,L*(1+pen)+1e-3*L*1000)   # tag wade steps by an offset to count them
        R.append(idx[A][ok]);C.append(idx[B][ok]);W.append(w)
    G=coo_matrix((np.concatenate(W),(np.concatenate(R),np.concatenate(C))),shape=(ny*nx,ny*nx)).tocsr()
    for a,b,nm in pairs:
        na=idx[int(a[1]/c),int(a[0]/c)]; nb=idx[int(b[1]/c),int(b[0]/c)]
        d,pred=dijkstra(G,indices=na,return_predecessors=True,directed=False)
        if not np.isfinite(d[nb]): print(mode,nm,"no path"); continue
        p=[nb]
        while p[-1]!=na: p.append(pred[p[-1]])
        P=np.array([(q%nx,q//nx) for q in p]); seg=np.hypot(*np.diff(P,axis=0).T)*c
        wet=np.array([not dry[q//nx,q%nx] for q in p[1:]])
        runs=np.diff(np.r_[0,wet.astype(int),0]); starts=np.where(runs==1)[0]; ends=np.where(runs==-1)[0]
        print(mode,nm,"path %.1f km (straight %.1f km)"%(seg.sum()/1000,math.dist(a,b)/1000), ("; wade crossings %d, total %.0f m, longest %.0f m"%(len(starts),seg[wet].sum(),max(seg[s_:e_].sum() for s_,e_ in zip(starts,ends))) if len(starts) else ""))
