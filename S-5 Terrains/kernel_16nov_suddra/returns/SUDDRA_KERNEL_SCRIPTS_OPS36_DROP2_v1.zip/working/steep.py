import sys,json,math,numpy as np
D=sys.argv[1]
h=np.load(D+"/suddra_height_cm.npz",allow_pickle=False)["height_cm"].astype(np.float32)/100
m=np.load(D+"/suddra_masks.npz",allow_pickle=False); W=m["water"]
def foot(x,y,p,yaw,step=4):
    t=math.radians(yaw or 0); U,V=np.meshgrid(np.arange(-p["hx"],p["hx"]+.1,step),np.arange(-p["hy"],p["hy"]+.1,step))
    X=x+U*math.cos(t)+V*math.sin(t); Y=y-U*math.sin(t)+V*math.cos(t)
    return np.clip(np.rint(Y/4).astype(int),0,4095),np.clip(np.rint(X/4).astype(int),0,4095)
for f,sid,comp in [("op3","3-03","Medium AA"),("op3","3-13","Heavy Gun"),("op3","3-M2","Large Power"),("op4","4-04","Heavy Gun"),("op4","4-05","Powerbank")]:
    P=json.load(open("part2_sketch/%s_plan_sketch_v3.json"%f)); s=[s for s in P["sites"] if s["id"]==sid][0]
    mb=[q for q in s["members"] if comp in q["comp"]][0]
    i,j=foot(mb["x"],mb["y"],mb["pad"],mb.get("yaw")); g=h[i,j]; w=W[i,j]
    lvl=max(0.5,float(np.median(g)))
    print(sid,s["name"],s["role"],mb["comp"],"(%.0f,%.0f) %.0fx%.0f"%(mb["x"],mb["y"],2*mb["pad"]["hx"],2*mb["pad"]["hy"]),
      "ground %+.2f..%+.2f rise %.2f; at level %+.2f: max cut %.2f, max fill %.2f, cells needing over 1 m %.0f%%, water %.1f%%"%(g.min(),g.max(),g.max()-g.min(),lvl,g.max()-lvl,lvl-g.min(),100*(abs(g-lvl)>1).mean(),100*w.mean()))
