import sys, json, math, numpy as np
from scipy import ndimage as nd
D=sys.argv[1]; plan=sys.argv[2]; sid=sys.argv[3]; R=float(sys.argv[4]) if len(sys.argv)>4 else 1500
h=np.load(D+"/suddra_height_cm.npz",allow_pickle=False)["height_cm"].astype(np.float32)/100
m=np.load(D+"/suddra_masks.npz",allow_pickle=False)
good=(m["ai_dry"]==1)&(m["water"]==0)&(h>=0.5)
P=json.load(open(plan)); s=[s for s in P["sites"] if s["id"]==sid][0]
mem=[mb for mb in s["members"] if isinstance(mb.get("pad"),dict)]
cx=np.mean([mb["x"] for mb in mem]); cy=np.mean([mb["y"] for mb in mem])
r=int(R/4); ci,cj=int(round(cy/4)),int(round(cx/4))
i0,i1,j0,j1=max(ci-r-60,0),min(ci+r+60,4095),max(cj-r-60,0),min(cj+r+60,4095)
g=good[i0:i1,j0:j1]; hh=h[i0:i1,j0:j1]
ok=np.ones_like(g); relief=np.zeros(g.shape,np.float32)
for mb in mem:
    p=mb["pad"]; yaw=math.radians(mb.get("yaw") or 0)
    hx=abs(p["hx"]*math.cos(yaw))+abs(p["hy"]*math.sin(yaw)); hy=abs(p["hx"]*math.sin(yaw))+abs(p["hy"]*math.cos(yaw))
    a=int(math.ceil(hy/4)); b=int(math.ceil(hx/4)); st=np.ones((2*a+1,2*b+1),bool)
    e=nd.binary_erosion(g,st,border_value=0)
    mx=nd.maximum_filter(hh,size=st.shape); mn=nd.minimum_filter(hh,size=st.shape)
    di,dj=int(round((mb["y"]-cy)/4)),int(round((mb["x"]-cx)/4))
    sh=lambda A,fill: np.roll(np.roll(A,-di,0),-dj,1)
    ok&=sh(e,0); relief=np.maximum(relief,sh(mx-mn,0))
I,J=np.nonzero(ok&(relief<=1.0))
Y=(I+i0)*4.0; X=(J+j0)*4.0; d=np.hypot(X-cx,Y-cy); k=d<=R
X,Y,d,rel=X[k],Y[k],d[k],relief[I[k],J[k]]
print("site",sid,"centre",round(cx),round(cy),"spots",len(d))
# pick up to 4 well-separated nearest spots in different directions
picks=[]
for idx in np.argsort(d):
    b=(math.degrees(math.atan2(X[idx]-cx,Y[idx]-cy)))%360
    if all(min(abs(b-pb),360-abs(b-pb))>45 for _,_,_,pb,_ in picks):
        picks.append((X[idx],Y[idx],d[idx],b,rel[idx]))
    if len(picks)==4: break
for x,y,dd,b,rl in picks: print("  spot %.0f,%.0f  moved %.0f m toward %.0f deg  ground %+.2f  relief %.2f"%(x,y,dd,b,h[int(y/4),int(x/4)],rl))
