import sys, numpy as np
from scipy import ndimage as nd
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
H=np.load(sys.argv[1]+"/ground/height_whole_cm.npz")["height_cm"]/100.0
x0,x1,y0,y1=3800,16000,0,10400
h=H[y0//5:y1//5,x0//5:x1//5]
water=h<=0.3; bad=nd.binary_dilation(water,iterations=2)
Hs=nd.gaussian_filter(h,1.5); ny,nx=h.shape; idx=np.arange(ny*nx).reshape(ny,nx)
pts={"1-F":(8200,3600),"3-M2":(11600,3400),"3-M1":(13600,5400),"3-F":(13200,2600),"3-14":(15775,4832),"4-04":(9600,6000),"4-M3":(9200,8600),"4-M1":(5190,7790),"4-F dam":(10390,7230)}
for lim in [float(a) for a in sys.argv[2:]]:
    R=[];C=[]
    for dj,di in [(0,1),(1,0),(1,1),(1,-1),(1,2),(2,1),(1,-2),(2,-1)]:
        L=5*np.hypot(dj,di)
        a=Hs[max(0,-dj):ny-max(0,dj), max(0,-di):nx-max(0,di)]; b=Hs[max(0,dj):ny-max(0,-dj)+ny*0 if dj>=0 else ny, :]
        A=np.s_[0:ny-dj, max(0,-di):nx-max(0,di)]; B=np.s_[dj:ny, max(0,di):nx-max(0,-di)]
        ok=(np.abs(Hs[A]-Hs[B])/L<=lim)&~bad[A]&~bad[B]
        R.append(idx[A][ok]); C.append(idx[B][ok])
    R=np.concatenate(R); C=np.concatenate(C)
    n,lab=connected_components(coo_matrix((np.ones(len(R),bool),(R,C)),shape=(ny*nx,ny*nx)),directed=False)
    lab=lab.reshape(ny,nx); sz=np.bincount(lab.ravel())
    out={}
    for k,(x,y) in pts.items():
        i,j=(y-y0)//5,(x-x0)//5; w=lab[i-8:i+9,j-8:j+9].ravel(); w=w[~bad[i-8:i+9,j-8:j+9].ravel()]
        l=int(np.bincount(w).argmax()) if w.size else -1; out[k]=(l, round(sz[l]*25/1e6,2) if l>=0 else 0)
    print("grade limit",lim,out)
