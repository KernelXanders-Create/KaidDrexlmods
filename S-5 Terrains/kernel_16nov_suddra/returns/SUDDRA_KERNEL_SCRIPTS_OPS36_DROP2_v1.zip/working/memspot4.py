import sys, json, math, numpy as np
D,plan,sid=sys.argv[1:4]; R=float(sys.argv[4]) if len(sys.argv)>4 else 400
h=np.load(D+"/suddra_height_cm.npz",allow_pickle=False)["height_cm"].astype(np.float32)/100
m=np.load(D+"/suddra_masks.npz",allow_pickle=False)
W=m["water"]; A=m["ai_dry"]; good=(A==1)&(W==0)&(h>=0.5)
P=json.load(open(plan)); s=[s for s in P["sites"] if s["id"]==sid][0]
print(sid,s["name"],s["role"],s["grade"],"sum_gps",s.get("sum_gps"))
def foot(x,y,p,yaw,step=4):
    t=math.radians(yaw or 0); U,V=np.meshgrid(np.arange(-p["hx"],p["hx"]+.1,step),np.arange(-p["hy"],p["hy"]+.1,step))
    X=x+U*math.cos(t)+V*math.sin(t); Y=y-U*math.sin(t)+V*math.cos(t)
    return np.clip(np.rint(Y/4).astype(int),0,4095),np.clip(np.rint(X/4).astype(int),0,4095)
mem=[mb for mb in s["members"] if isinstance(mb.get("pad"),dict)]
for k,mb in enumerate(mem):
    i,j=foot(mb["x"],mb["y"],mb["pad"],mb.get("yaw")); g=h[i,j]
    gn=(mb.get("guns") or [{}])[0]
    print("  [%d] %s (%.0f,%.0f) %.0fx%.0f m yaw %s: water %.0f%%, ai_dry %.0f%%, good %.0f%%, ground %+.2f..%+.2f%s"%(k,mb["comp"],mb["x"],mb["y"],2*mb["pad"]["hx"],2*mb["pad"]["hy"],mb.get("yaw"),100*W[i,j].mean(),100*A[i,j].mean(),100*good[i,j].mean(),g.min(),g.max(),
      ("; %s guns at %s deg"%(gn.get("guns"),gn.get("bearing")) if gn else "")))
    if True:
        occ=np.zeros_like(good)
        for o in mem:
            if o is not mb: oi,oj=foot(o["x"],o["y"],o["pad"],o.get("yaw")); occ[oi,oj]=1
        res=[]
        for dx in np.arange(-R,R+1,8):
            for dy in np.arange(-R,R+1,8):
                d=math.hypot(dx,dy)
                if d>R: continue
                ii,jj=foot(mb["x"]+dx,mb["y"]+dy,mb["pad"],mb.get("yaw"),6)
                if good[ii,jj].all() and not occ[ii,jj].any():
                    gg=h[ii,jj]
                    if gg.max()-gg.min()<=2.0: res.append((d,mb["x"]+dx,mb["y"]+dy,math.degrees(math.atan2(dx,dy))%360,float(gg.mean())))
        res.sort(); picks=[]
        for r in res:
            if all(min(abs(r[3]-p[3]),360-abs(r[3]-p[3]))>60 for p in picks): picks.append(r)
            if len(picks)==3: break
        for p in picks: print("      dry spot (%.0f,%.0f) moved %.0f m toward %.0f deg, mean ground %+.2f"%(p[1],p[2],p[0],p[3],p[4]))
        if not picks: print("      no dry spot within",R,"m")
