import sys, json, math, numpy as np
from scipy import ndimage as nd
D,plan,sid=sys.argv[1:4]; R=float(sys.argv[4]) if len(sys.argv)>4 else 400
h=np.load(D+"/suddra_height_cm.npz",allow_pickle=False)["height_cm"].astype(np.float32)/100
m=np.load(D+"/suddra_masks.npz",allow_pickle=False)
good=(m["ai_dry"]==1)&(m["water"]==0)&(h>=0.5)
P=json.load(open(plan)); s=[s for s in P["sites"] if s["id"]==sid][0]
print(sid,s["name"],s["role"],s["grade"],"sum_gps",s.get("sum_gps"))
def ext(mb):
    p=mb["pad"]; t=math.radians(mb.get("yaw") or 0)
    return abs(p["hx"]*math.cos(t))+abs(p["hy"]*math.sin(t)), abs(p["hx"]*math.sin(t))+abs(p["hy"]*math.cos(t))
mem=[mb for mb in s["members"] if isinstance(mb.get("pad"),dict)]
for k,mb in enumerate(mem):
    hx,hy=ext(mb); x,y=mb["x"],mb["y"]
    i,j=int(round(y/4)),int(round(x/4)); a,b=int(math.ceil(hy/4)),int(math.ceil(hx/4))
    blk=good[i-a:i+a+1,j-b:j+b+1]; wet=1-blk.mean()
    g=h[i-a:i+a+1,j-b:j+b+1]
    line="  [%d] %s at (%.0f,%.0f) %dx%d m yaw %s: bad %.0f%%, ground %+.2f..%+.2f"%(k,mb["comp"],x,y,2*hx,2*hy,mb.get("yaw"),100*wet,g.min(),g.max())
    gn=mb.get("guns") or []
    if gn: line+="; guns %s bearing %s"%(gn[0].get("guns"),gn[0].get("bearing"))
    print(line)
    if wet>0.1:
        r=int(R/4); i0,j0=i-r-a,j-r-b
        G=good[i0:i+r+a+1,j0:j+r+b+1]; HH=h[i0:i+r+a+1,j0:j+r+b+1]
        st=np.ones((2*a+1,2*b+1),bool); e=nd.binary_erosion(G,st,border_value=0)
        rel=nd.maximum_filter(HH,size=st.shape)-nd.minimum_filter(HH,size=st.shape)
        ok=e&(rel<=1.0)
        # no overlap with other members' pads
        for o in mem:
            if o is mb: continue
            ox,oy=ext(o); I,J=np.mgrid[0:G.shape[0],0:G.shape[1]]
            X=(J+j0)*4.0; Y=(I+i0)*4.0
            ok&=~((abs(X-o["x"])<hx+ox+5)&(abs(Y-o["y"])<hy+oy+5))
        I,J=np.nonzero(ok); X=(J+j0)*4.0; Y=(I+i0)*4.0; d=np.hypot(X-x,Y-y)
        picks=[]
        for q in np.argsort(d):
            br=math.degrees(math.atan2(X[q]-x,Y[q]-y))%360
            if all(min(abs(br-p[3]),360-abs(br-p[3]))>60 for p in picks): picks.append((X[q],Y[q],d[q],br,h[int(Y[q]/4),int(X[q]/4)]))
            if len(picks)==3: break
        for p in picks: print("      dry spot (%.0f,%.0f) moved %.0f m toward %.0f deg, ground %+.2f"%p)
