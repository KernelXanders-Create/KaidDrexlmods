import sys, json, numpy as np, os
d=sys.argv[1]
H=np.load(os.path.join(d,"suddra_height_cm.npz"),allow_pickle=False)
print("height keys",H.files)
h=H["height_cm"]; print(h.shape,h.dtype,"range m",h.min()/100,h.max()/100)
for k in H.files:
    if k!="height_cm": print(" ",k,H[k])
M=np.load(os.path.join(d,"suddra_masks.npz"),allow_pickle=False)
for k in M.files:
    a=M[k]; print("mask",k,a.shape,a.dtype,"vals",np.unique(a)[:8],"share %.2f%%"%(100*(a>0).mean()))
for f in sorted(os.listdir(d)):
    if f.endswith(".json"):
        j=json.load(open(os.path.join(d,f))); print("json",f,"ok", list(j)[:8] if isinstance(j,dict) else type(j))
