# Suddra: scripts behind Kernel's ops 3-6 return — v3

Made on 2026-11-27. v3 replaces v2. Since v2 it adds `hamlet513/` (the 5-13 rise, point, guard seats and the house fit) and `offnet/` (the player and AI ways in). v2 replaced v1. It adds `tools_sketch/approaches56_v2.py`, the reviewed op 5-6 approaches, which `op5d.py` and `op6d.py` now read. It also adds `town64/town64_guards.py`, the 6-M4 FOB and gun seat search.

This is the companion to `SUDDRA_KERNEL_RETURN_OPS36_DROP2_v3.zip`, which has the plans, checks and docs. This zip has the scripts that made them, so the ground packs and plans can be built again.

Run with Python 3.13, numpy 2.5.3, scipy 1.18.1, shapely 2.2.0 and matplotlib 3.11.2. These are the versions used; others are untested.

## What is in it

| Folder | What it holds |
|---|---|
| `tools_sketch/` | The road planner (`planner.py`, `run_op.py`, `world.py`), its checks (`sudcheck.py`, `verify.py`), sizes, and every op module (`op3r*.py`, `op4r*.py`, `op5*.py`, `op6*.py`, `op58d.py`). Each module builds on the one it imports |
| `packs/` | The ground pack builders, from the base pack through v2 to v10, plus the two data files they read (`causeway58_v1.json`, `approaches36/causeway36_v1.jsonl`) |
| `pack_inputs/sketch_pack/` | The small, non-ground part of the sketch pack that the base builder copies in: `design/` (objectives, purpose map), `ops_1_2/` (pads), `ground/roads_ops_1_2.json` |
| `checks_ops58/` | The ops 5-8 ground, pad, layout, road and causeway checks |
| `approaches36/`, `town64/`, `handoff78/` | The approaches check, the 6-M4 town joins, and the ops 7-8 hand-off measurements |
| `deps/town_grader.py` | The K6 grader that `run_op.py` imports for house footprints (from `kernel_10nov_v1/K6/grader`) |
| `working/` | Scratch scripts used along the way and not cited by any doc. They are kept so nothing is lost, but they are not needed to rebuild anything |

## How the ground packs were built

Inputs not in this zip:
- the drop 2 heights, `drop2_pack5_20261124/drop2/suddra_height_cm.npz`;
- the ops 3-4 sketch plans, `job2/part2_sketch/op3_plan_sketch_v3.json` and `op4_plan_sketch_v3.json`.

Both are in the repository.

```bash
python3 packs/build_pack_drop2.py <drop2 folder> pack_inputs/sketch_pack <base pack> <part2_sketch folder>
```

Each later builder takes the pack before it and writes a new one:

| Pack | Built from | Builder |
|---|---|---|
| v2 | base | `build_pack_drop2_v2.py` (not used by any later pack) |
| v3 | base | `build_pack_drop2_v3.py` |
| v4 | v3 | `build_pack_drop2_v4.py` |
| v5 | v4 | `build_pack_drop2_v5.py` |
| v6 | v5 | `build_pack_drop2_v6.py`, with `causeway58_v1.json` as a third argument |
| v7 | v6 | `build_pack_drop2_v7.py` |
| v8 | v7 | `build_pack_drop2_v8.py`; reads `approaches36/causeway36_v1.jsonl` next to itself |
| v9 | v8 | `build_pack_drop2_v9.py` |
| v10 | v9 | `build_pack_drop2_v10.py` |

Every builder appends its changes to the pack's `ground_requests_applied.json`.

## How the final plans were run

Run from `tools_sketch/`. `PACK_C` names the ground pack. `run_op.py` finds the grader at `../../../kernel_10nov_v1/K6/grader`, so either keep the repository layout or put `deps/` on that path.

| Plan | Pack | Module | Output name |
|---|---|---|---|
| Op 3 | v9 | `op3r7` | op37 |
| Op 4 north / south | v5 | `op4r3n` / `op4r3s` | op43 |
| Op 5 (all but 5-12) | v7 | `op5e` | op5 |
| Op 6 | v8 | `op6e` | op6 |

```bash
PACK_C=<pack> timeout 6900 python3 -u run_op.py <module> <output folder>
```

- Runs that pass 2 hours were lost, so each run is wrapped in `timeout 6900`.
- Op 3 took 58 min. The 5-12 runs took about 70 min each.
- `world.py` falls back to a scratch path when `PACK_C` is not set, so always set it.

## Checks after the plans

- **Approaches:** run `approaches36/approach36.py` from the `kernel_16nov_suddra` folder. Set `APPROACH_PLANS` to a JSON map of op to plan files, and `APPROACH_OUT` to the output name. The final run used op 3 `run_a6`, op 4 v5, op 5 v4 main and op 6 `run_a4`.
- **Town joins:** `town64/town64.py <pack> <op 6 plan> <out>`, then `town64_t1.py <pack> <plan>` and `town64_t2.py <pack>`.
- **Town guards:** `town64/town64_guards.py <pack> <op 6 plan> <out>` (pack v10, op 6 `run_a4`).
- **5-13 hamlet:** run these from `job5/drop2_check`:
  - `hamlet513/rise513.py <pack> <op 5 plan> <out>`
  - `point513.py <pack> <op 5 plan> <out>`
  - `guards513.py <pack> <op 5 plan> <out>`
  - then `housefit.py <pack> <op 6 plan> <op 5 plan> <out>`
- **Ways in:**
  - `offnet/offnet5.py <drop2 folder> <op 5 plan> <out>`
  - `offnet/offnet36.py <drop2 folder> offnet/offnet36_spec.json <out>`. Set `OFFNET_R` for the search box (default 3,500 m); `OFFNET_AI_ONLY` and `OFFNET_ONLY` limit a run. Run with `python3 -I`, since it reads the drop 2 masks.
- **Hand-off:** run `handoff78/handoff78.py` from `job5/drop2_check`.
